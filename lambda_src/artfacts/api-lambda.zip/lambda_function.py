"""Accounts API handler.

Main flow:
- GET: query account by email or AccountId.
- POST: validate input, save request in DynamoDB, and delegate async processing.
"""

import json
import boto3
import os
import uuid
import logging
from datetime import datetime, timezone
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Attr

# Logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# AWS Clients
sfn_client = boto3.client("stepfunctions")
dynamodb = boto3.resource("dynamodb")
org_client = boto3.client("organizations")

TABLE_NAME = os.environ.get("DYNAMO_TABLE", "accfactory-ddb-accounts")
if not TABLE_NAME:
    raise RuntimeError("Missing required environment variable DYNAMO_TABLE")
table = dynamodb.Table(TABLE_NAME)
SFN_ARN = os.environ.get("SFN_ARN")
SFN_MAX_CONCURRENT = int(os.environ.get("SFN_MAX_CONCURRENT", "5"))


def format_name(name):
    """Normalize capitalization for person names."""
    return " ".join([part.capitalize() for part in name.strip().split()])


def has_available_capacity():
    """Check if Step Function has capacity for new executions."""
    if not SFN_ARN:
        return True
    try:
        running = 0
        next_token = None
        while True:
            params = {
                "stateMachineArn": SFN_ARN,
                "statusFilter": "RUNNING",
            }
            if next_token:
                params["nextToken"] = next_token
            response = sfn_client.list_executions(**params)
            running += len(response.get("executions", []))
            if running >= SFN_MAX_CONCURRENT or "nextToken" not in response:
                break
            next_token = response["nextToken"]
        return running < SFN_MAX_CONCURRENT
    except Exception as exc:
        logger.error(f"Erro ao verificar execuções do Step Function: {exc}")
        return True


def lambda_handler(event, context):
    """HTTP entry point (API Gateway proxy integration)."""
    method = event.get("httpMethod")
    logger.info(f"HTTP Method: {method}")
    logger.info(f"Event received: {json.dumps(event)}")

    if method == "GET":
        params = event.get("queryStringParameters") or {}
        account_email = params.get("accountEmail")
        account_id = params.get("accountId")
        return get_account(account_email, account_id)

    elif method == "POST":
        try:
            body = json.loads(event.get("body", "{}"))
        except json.JSONDecodeError:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Invalid JSON format"}),
            }
        if not has_available_capacity():
            return {
                "statusCode": 429,
                "body": json.dumps({"error": "Too many requests in progress"}),
            }

        # Validate required fields.
        required_fields = [
            "AccountEmail",
            "AccountName",
            "OrgUnit",
            "SSOUserEmail",
            "SSOUserFirstName",
            "SSOUserLastName",
        ]
        missing = [f for f in required_fields if f not in body or not body[f]]
        if missing:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": f"Missing fields: {', '.join(missing)}"}),
            }

        # Normalize name capitalization.
        body["SSOUserFirstName"] = format_name(body["SSOUserFirstName"])
        body["SSOUserLastName"] = format_name(body["SSOUserLastName"])

        return create_account(body)

    else:
        return {"statusCode": 405, "body": json.dumps({"error": "Method not allowed"})}


# ---------------- GET ----------------
def get_account(account_email=None, account_id=None):
    """Query account from DynamoDB by email (PK) or AccountId."""
    try:
        if account_email:
            response = table.get_item(
                Key={"AccountEmail": account_email.strip().lower()}
            )
            item = response.get("Item")
            if not item:
                return {
                    "statusCode": 404,
                    "body": json.dumps({"error": "Account not found"}),
                }
            return {"statusCode": 200, "body": json.dumps(item)}

        elif account_id:
            response = table.scan(FilterExpression=Attr("AccountId").eq(account_id))
            items = response.get("Items", [])
            if not items:
                return {
                    "statusCode": 404,
                    "body": json.dumps({"error": "Account not found"}),
                }
            return {"statusCode": 200, "body": json.dumps(items[0])}

        else:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Provide accountEmail or accountId"}),
            }

    except Exception as e:
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}


# ---------------- POST ----------------
def create_account(data):
    """Create an account request in DynamoDB with initial Requested status."""
    if not validate_account_name(data["AccountName"]):
        return {
            "statusCode": 409,
            "body": json.dumps({"error": "AccountName already exists"}),
        }
    if not validate_org_unit(data["OrgUnit"]):
        return {
            "statusCode": 400,
            "body": json.dumps({"error": f"Invalid OrgUnit: {data['OrgUnit']}"}),
        }

    request_id = str(uuid.uuid4())
    timestamp = datetime.now(timezone.utc).isoformat()

    item = {
        "AccountEmail": data["AccountEmail"].strip().lower(),
        "AccountName": data["AccountName"].strip(),
        "SSOUserEmail": data["SSOUserEmail"].strip().lower(),
        "SSOUserFirstName": data["SSOUserFirstName"],
        "SSOUserLastName": data["SSOUserLastName"],
        "OrgUnit": data["OrgUnit"],
        "Status": "Requested",
        "RequestID": request_id,
        "CreatedAt": timestamp,
        "UpdatedAt": timestamp,
        "LastUpdateDate": timestamp,
    }

    if "Tags" in data:
        item["Tags"] = data["Tags"]

    try:
        table.put_item(
            Item=item, ConditionExpression="attribute_not_exists(AccountEmail)"
        )
        return {"statusCode": 201, "body": json.dumps(item)}
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            return {
                "statusCode": 409,
                "body": json.dumps({"error": "Account already exists"}),
            }
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}


# ---------------- Validation ----------------
def validate_org_unit(ou_path):
    """Validate that the OU path exists (for example: Engineering/Platform)."""
    try:
        # Use organization root as the starting point.
        roots = org_client.list_roots()
        if not roots.get("Roots"):
            logger.error("Nenhum root encontrado na organização")
            return False

        current_parent_id = roots["Roots"][0]["Id"]
        ou_parts = [part.strip() for part in ou_path.split("/") if part.strip()]

        # Resolve each path segment (Engineering, Platform, ...).
        for ou_name in ou_parts:
            found = False
            paginator = org_client.get_paginator("list_organizational_units_for_parent")

            # List OUs under current parent.
            for page in paginator.paginate(ParentId=current_parent_id):
                for ou in page["OrganizationalUnits"]:
                    if ou["Name"].lower() == ou_name.lower():
                        current_parent_id = ou["Id"]  # Move to next level.
                        found = True
                        break
                if found:
                    break

            # If a segment is not found, the OU path is invalid.
            if not found:
                logger.warning(
                    f"OU não encontrada no caminho: {ou_path} (parou em: {ou_name})"
                )
                return False

        # Full path resolved.
        return True

    except Exception as e:
        logger.error(f"Erro ao validar OU path '{ou_path}': {str(e)}")
        return False


def validate_account_name(account_name):
    """Ensure there is no existing account with the same name in DynamoDB."""
    try:
        response = table.scan(
            FilterExpression=Attr("AccountName").eq(account_name.strip().lower())
        )
        return len(response.get("Items", [])) == 0
    except Exception:
        return False
